from recognition import FaceRecognition


if __name__ == '__main__':
    fr = FaceRecognition()
    fr.run_recognition()